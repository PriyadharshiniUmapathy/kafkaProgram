package com.company.examples.examples.examples.kafka.examples;

public class AppsConfig {
    final static String applicationID = "TransactoinalCommit";
    final static String bootstrapServers = "localhost:9092,localhost:9093";
    final static String topicName1 = "trans-topic-1";
    final static String topicName2 = "trans-topic-2";
    final static int numEvents= 2;
    final static String Transaction_id = "transaction-commit";
}


